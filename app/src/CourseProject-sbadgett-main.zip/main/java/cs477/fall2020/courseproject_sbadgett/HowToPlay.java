package cs477.fall2020.courseproject_sbadgett;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HowToPlay extends AppCompatActivity {

    @Override
    /*
    This activity simply has a bunch of text explaining the game and this app
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to_play);
    }
}